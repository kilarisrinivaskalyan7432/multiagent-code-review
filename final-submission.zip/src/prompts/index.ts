/**
 * Centralized prompt management
 */

export { CODE_QUALITY_ANALYZER_PROMPT } from './code-quality-analyzer.prompt.js';
export { TEST_COVERAGE_ANALYZER_PROMPT } from './test-coverage-analyzer.prompt.js';
export { REFACTORING_SUGGESTER_PROMPT } from './refactoring-suggester.prompt.js';
export { ORCHESTRATOR_PROMPT } from './orchestrator.prompt.js';
